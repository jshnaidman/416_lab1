This code was written and tested using java 1.8

The code can be compiled by simply executing:
javac DnsClient.java

The code can be ran by executing:
java DnsClient [-t timeout] [-r max-retries] [-p port] [-mx|-ns] @server name